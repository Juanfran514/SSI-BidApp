package validators;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;

public class USBSigner {

    public static final String privateKeyPassword = "1234";
    private static final String OPENSSL_PATH = "C:\\Program Files\\OpenSSL-Win64\\bin\\openssl.exe"; // Ruta a OpenSSL

    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("⏳ Esperando USB...");

        File usbDrive = detectarUSB();
        if (usbDrive == null) {
            System.out.println("❌ No se detectó una USB. Intenta conectarla y reiniciar el programa.");
            return;
        }

        System.out.println("¡USB detectada en: " + usbDrive.getAbsolutePath() + "!");

        // Buscar CSR y clave privada, luego generar certificado autofirmado
        File csrFile = findFile(usbDrive, ".csr");
        File keyFile = findFile(usbDrive, ".key");

        if (csrFile != null && keyFile != null) {
            System.out.println("✅ CSR encontrado: " + csrFile.getName());
            System.out.println("✅ Clave privada encontrada: " + keyFile.getName());
            generarCertificadoAutofirmado(csrFile, keyFile,privateKeyPassword);
        } else {
            System.out.println("❌ No se encontró CSR o clave privada en la USB.");
        }

        monitorearUSB(usbDrive.toPath());
    }

    // 🔍 Detectar la unidad USB conectada
    public static File detectarUSB() {
        File[] roots = File.listRoots();
        for (File root : roots) {
            if (esUSB(root)) {
                return root;
            }
        }
        return null;
    }

    // 📂 Verifica si la unidad es USB (evitar C:\ y detectar otras unidades)
    private static boolean esUSB(File unidad) {
        String path = unidad.getAbsolutePath();
        if (path.equals("C:\\")) {
            return false; // No es una USB si es C:
        }
        return unidad.canRead() && unidad.canWrite();
    }

    // 👀 Monitorear cambios en la USB
    private static void monitorearUSB(Path usbPath) throws IOException, InterruptedException {
        try (WatchService watchService = FileSystems.getDefault().newWatchService()) {
            usbPath.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);

            System.out.println("🔍 Monitoreando: " + usbPath);

            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    Path detected = usbPath.resolve((Path) event.context());
                    File usbFile = detected.toFile();

                    if (usbFile.isFile() && (usbFile.getName().endsWith(".csr") || usbFile.getName().endsWith(".key"))) {
                        System.out.println("✅ Nuevo archivo detectado: " + usbFile.getName());
                        File csrFile = findFile(usbPath.toFile(), ".csr");
                        File keyFile = findFile(usbPath.toFile(), ".key");

                        if (csrFile != null && keyFile != null) {
                            System.out.println("✅ CSR y clave privada encontrados.");
                            generarCertificadoAutofirmado(csrFile, keyFile,privateKeyPassword);
                        }
                    }
                }
                key.reset();
            }
        }
    }

    // 🧐 Buscar un archivo con extensión específica en la USB
    public static File findFile(File directory, String extension) {
        File[] files = directory.listFiles((dir, name) -> name.endsWith(extension));
        return (files != null && files.length > 0) ? files[0] : null;
    }

    // 🔏 Generar certificado autofirmado a partir del CSR y la clave privada
    public static void generarCertificadoAutofirmado(File csrFile, File keyFile, String privateKeyPassword) {
        try {
            // Ruta al archivo CSR
            String csrPath = csrFile.getAbsolutePath();

            // Ruta a la clave privada
            String keyPath = keyFile.getAbsolutePath();

            // Ruta al archivo de salida (certificado autofirmado)
            String certPath = csrFile.getParent() + "\\self_signed_certificate.crt";

            // El comando exacto que quieres ejecutar, incluyendo la contraseña de la clave privada
            String command = String.format(
                "\"C:\\Program Files\\OpenSSL-Win64\\bin\\openssl.exe\" x509 -req -in \"%s\" -signkey \"%s\" -out \"%s\" -days 365 -sha256 -passin pass:%s",
                csrPath, keyPath, certPath, privateKeyPassword
            );

            // Mostrar el comando antes de ejecutarlo
            System.out.println("Ejecutando comando: " + command);

            // Usamos ProcessBuilder para ejecutar el comando
            ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
            processBuilder.directory(new File(System.getProperty("user.dir")));  // Establece el directorio actual
            processBuilder.redirectErrorStream(true);  // Redirige el flujo de error al estándar

            // Ejecutar el proceso
            Process process = processBuilder.start();

            // Leer la salida estándar y de error
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }

            // Esperar a que el proceso termine
            int exitCode = process.waitFor();

            // Verificar si el certificado se generó correctamente
            File signedCert = new File(certPath);
            if (signedCert.exists()) {
                System.out.println("✅ Certificado autofirmado generado: " + signedCert.getName());
            } else {
                System.out.println("❌ Error al generar el certificado autofirmado.");
            }

            // Mostrar la salida del proceso
            System.out.println("Salida del proceso: ");
            System.out.println(output.toString());

            // Mostrar el código de salida del proceso para más detalles
            System.out.println("Código de salida del proceso: " + exitCode);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            System.out.println("❌ Error al generar el certificado autofirmado.");
        }
    }

}